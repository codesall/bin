import java.util.Arrays;

public class BestWorst   {

    // Method for Best Fit memory placement
    public static void bestFit(int[] blockSizes, int[] processSizes) {
        int[] allocation = new int[processSizes.length];
        Arrays.fill(allocation, -1);  // Initialize all allocations as -1 (not allocated)

        for (int i = 0; i < processSizes.length; i++) {
            int bestIdx = -1;
            for (int j = 0; j < blockSizes.length; j++) {
                if (blockSizes[j] >= processSizes[i]) {
                    if (bestIdx == -1 || blockSizes[j] < blockSizes[bestIdx]) {
                        bestIdx = j;  // Find the block with the smallest size that fits
                    }
                }
            }

            // If we found a suitable block for the process
            if (bestIdx != -1) {
                allocation[i] = bestIdx;
                blockSizes[bestIdx] -= processSizes[i];
            }
        }

        System.out.println("Best Fit Allocation:");
        printAllocation(processSizes, allocation);
    }

    // Method for Worst Fit memory placement
    public static void worstFit(int[] blockSizes, int[] processSizes) {
        int[] allocation = new int[processSizes.length];
        Arrays.fill(allocation, -1);  // Initialize all allocations as -1 (not allocated)

        for (int i = 0; i < processSizes.length; i++) {
            int worstIdx = -1;
            for (int j = 0; j < blockSizes.length; j++) {
                if (blockSizes[j] >= processSizes[i]) {
                    if (worstIdx == -1 || blockSizes[j] > blockSizes[worstIdx]) {
                        worstIdx = j;  // Find the block with the largest size that fits
                    }
                }
            }

            // If we found a suitable block for the process
            if (worstIdx != -1) {
                allocation[i] = worstIdx;
                blockSizes[worstIdx] -= processSizes[i];
            }
        }

        System.out.println("Worst Fit Allocation:");
        printAllocation(processSizes, allocation);
    }

    // Helper method to print allocation results
    private static void printAllocation(int[] processSizes, int[] allocation) {
        System.out.println("Process No.\tProcess Size\tBlock No.");
        for (int i = 0; i < processSizes.length; i++) {
            System.out.print(" " + (i + 1) + "\t\t" + processSizes[i] + "\t\t");
            if (allocation[i] != -1) {
                System.out.println(allocation[i] + 1);  // Output block number (1-indexed)
            } else {
                System.out.println("Not Allocated");
            }
        }
        System.out.println();
    }

    public static void main(String[] args) {
        int[] blockSizes = {100, 500, 200, 300, 600};  // Memory block sizes
        int[] processSizes = {212, 417, 112, 426};     // Process sizes

        // Copy block sizes for each strategy as they are modified in place
        int[] blockSizesForBestFit = Arrays.copyOf(blockSizes, blockSizes.length);
        int[] blockSizesForWorstFit = Arrays.copyOf(blockSizes, blockSizes.length);

        bestFit(blockSizesForBestFit, processSizes);  // Perform Best Fit allocation
        worstFit(blockSizesForWorstFit, processSizes);  // Perform Worst Fit allocation
    }
}
