import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

class Process {
    String name;
    int arrivalTime;
    int burstTime;
    int priority;
    int waitingTime = 0;
    int turnaroundTime = 0;
    int completionTime = 0;
    boolean isCompleted = false;

    public Process(String name, int arrivalTime, int burstTime, int priority) {
        this.name = name;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
        this.priority = priority;
    }
}

public class PriorityNonPreemptive {
    public static void main(String[] args) {
        List<Process> processes = new ArrayList<>();
        processes.add(new Process("P1", 10, 2, 2));
        processes.add(new Process("P2", 0, 10, 1));
        processes.add(new Process("P3", 8, 4, 3));
        processes.add(new Process("P4", 5, 5, 2));

        // Sort processes by arrival time initially
        processes.sort(Comparator.comparingInt(p -> p.arrivalTime));

        int currentTime = 0;
        int completed = 0;
        int n = processes.size();

        while (completed != n) {
            // Select the highest-priority process that has arrived
            Process highestPriorityProcess = null;
            for (Process process : processes) {
                if (process.arrivalTime <= currentTime && !process.isCompleted) {
                    if (highestPriorityProcess == null || process.priority < highestPriorityProcess.priority) {
                        highestPriorityProcess = process;
                    }
                }
            }

            if (highestPriorityProcess == null) {
                currentTime++;
            } else {
                // Process the selected highest-priority job
                currentTime += highestPriorityProcess.burstTime;
                highestPriorityProcess.completionTime = currentTime;
                highestPriorityProcess.turnaroundTime = highestPriorityProcess.completionTime - highestPriorityProcess.arrivalTime;
                highestPriorityProcess.waitingTime = highestPriorityProcess.turnaroundTime - highestPriorityProcess.burstTime;
                highestPriorityProcess.isCompleted = true;
                completed++;
            }
        }

        // Display results
        System.out.println("Process\tArrival Time\tBurst Time\tPriority\tWaiting Time\tTurnaround Time\tCompletion Time");
        double totalWaitingTime = 0, totalTurnaroundTime = 0;
        for (Process process : processes) {
            System.out.printf("%s\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\n",
                    process.name, process.arrivalTime, process.burstTime, process.priority, process.waitingTime, process.turnaroundTime, process.completionTime);
            totalWaitingTime += process.waitingTime;
            totalTurnaroundTime += process.turnaroundTime;
        }

        System.out.printf("\nAverage Waiting Time: %.2f\n", totalWaitingTime / n);
        System.out.printf("Average Turnaround Time: %.2f\n", totalTurnaroundTime / n);
    }
}
