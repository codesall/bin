import java.util.LinkedList;
import java.util.Queue;

public class FIFOPage {
    // Method to simulate FIFO page replacement algorithm
    public static void fifoPageReplacement(int[] referenceString, int frames) {
        Queue<Integer> memory = new LinkedList<>(); // FIFO queue to represent frames in memory
        int pageFaults = 0;

        System.out.println("Reference String\tMemory Frames");

        for (int page : referenceString) {
            if (!memory.contains(page)) {
                // Page Fault occurs
                if (memory.size() == frames) {
                    memory.poll(); // Remove the oldest page (FIFO)
                }
                memory.add(page); // Add the new page to the frames
                pageFaults++;
                System.out.printf("%d\t\t\t%s (Page Fault)\n", page, memory);
            } else {
                System.out.printf("%d\t\t\t%s\n", page, memory);
            }
        }

        System.out.println("\nTotal Page Faults: " + pageFaults);
    }

    public static void main(String[] args) {
        int[] referenceString = {2, 3, 2, 1, 5, 2, 4, 5, 3, 2, 5, 2}; // Input reference string
        int frames = 3; // Number of frames

        fifoPageReplacement(referenceString, frames);
    }
}
