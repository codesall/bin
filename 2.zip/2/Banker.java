import java.util.Arrays;

public class Banker{

    // Method to check if the system is in a safe state
    public static boolean isSafe(int processes, int resources, int[] available, int[][] max, int[][] allocation, int[][] need) {
        int[] work = Arrays.copyOf(available, available.length);  // Work vector
        boolean[] finish = new boolean[processes];  // Finish vector
        Arrays.fill(finish, false);  // Initialize all processes as not finished

        int count = 0;  // To count how many processes have finished

        while (count < processes) {
            boolean progressMade = false;

            for (int i = 0; i < processes; i++) {
                if (!finish[i] && canAllocate(need[i], work)) {
                    // If the process's needs can be met with the available resources, allocate the resources
                    for (int j = 0; j < resources; j++) {
                        work[j] += allocation[i][j];  // Simulate allocation
                    }
                    finish[i] = true;  // Mark the process as finished
                    progressMade = true;
                    count++;
                    break;  // Restart the loop to check for another process
                }
            }

            // If no progress is made, then the system is in an unsafe state
            if (!progressMade) {
                return false;
            }
        }
        return true;  // If all processes can finish, the system is in a safe state
    }

    // Helper method to check if resources can be allocated to a process
    public static boolean canAllocate(int[] need, int[] work) {
        for (int i = 0; i < need.length; i++) {
            if (need[i] > work[i]) {
                return false;  // If the process needs more than what is available, it cannot be allocated
            }
        }
        return true;
    }

    // Method to request resources and check for safety
    public static boolean requestResources(int process, int[] request, int[] available, int[][] max, int[][] allocation, int[][] need) {
        // Check if the request is less than or equal to the need
        for (int i = 0; i < request.length; i++) {
            if (request[i] > need[process][i]) {
                System.out.println("Error: Process has exceeded its maximum claim.");
                return false;
            }
        }

        // Check if the request is less than or equal to available resources
        for (int i = 0; i < request.length; i++) {
            if (request[i] > available[i]) {
                System.out.println("Error: Not enough resources available.");
                return false;
            }
        }

        // Pretend to allocate the resources and check if the system is in a safe state
        int[] availableCopy = Arrays.copyOf(available, available.length);
        int[][] allocationCopy = new int[allocation.length][];
        int[][] needCopy = new int[need.length][];

        for (int i = 0; i < allocation.length; i++) {
            allocationCopy[i] = Arrays.copyOf(allocation[i], allocation[i].length);
            needCopy[i] = Arrays.copyOf(need[i], need[i].length);
        }

        // Temporarily allocate the resources
        for (int i = 0; i < request.length; i++) {
            availableCopy[i] -= request[i];
            allocationCopy[process][i] += request[i];
            needCopy[process][i] -= request[i];
        }

        // Check if the system is in a safe state after the allocation
        if (isSafe(allocation.length, available.length, availableCopy, max, allocationCopy, needCopy)) {
            System.out.println("Request granted.");
            return true;
        } else {
            System.out.println("Request cannot be granted (unsafe state).");
            return false;
        }
    }

    public static void main(String[] args) {
        // Number of processes and resources
        int processes = 5;
        int resources = 3;

        // Available resources
        int[] available = {3, 3, 2};

        // Maximum resources required by each process
        int[][] max = {
            {7, 5, 3},
            {3, 2, 2},
            {9, 0, 2},
            {2, 2, 2},
            {4, 3, 3}
        };

        // Resources currently allocated to each process
        int[][] allocation = {
            {0, 1, 0},
            {2, 0, 0},
            {3, 0, 2},
            {2, 1, 1},
            {0, 0, 2}
        };

        // Calculate the need matrix (Need = Max - Allocation)
        int[][] need = new int[processes][resources];
        for (int i = 0; i < processes; i++) {
            for (int j = 0; j < resources; j++) {
                need[i][j] = max[i][j] - allocation[i][j];
            }
        }

        // Check the system's safe state
        if (isSafe(processes, resources, available, max, allocation, need)) {
            System.out.println("System is in a safe state.");
        } else {
            System.out.println("System is not in a safe state.");
        }

        // Request resources for a process (example: Process 1 requests [1, 0, 2])
        int[] request = {1, 0, 2};  // Process 1 requests 1 of resource 1, 0 of resource 2, and 2 of resource 3
        requestResources(1, request, available, max, allocation, need);
    }
}
