import java.util.Arrays;
import java.util.Comparator;

class Process{
    String name;
    int AT;
    int bT;
    int wT;
    int TT;
    int CT;

    public Process(String name, int AT,int bT){
        this.name = name;
        this.AT=AT;
        this.bT = bT;
    }

}


public class Practice {
    public static void main(String[] args) {
        Process []  processes = {
        new Process("P1",10,2),
        new Process("P2", 0, 10),
        new Process("P3", 8, 4),
        new Process("P4", 5, 5)
        } ;
        Arrays.sort(processes,Comparator.comparingInt(p->p.AT));
        int currentTime = 0;

        for (Process process:processes){
            if(currentTime <process.AT){
                currentTime = process.AT;
            }
            process.CT = currentTime +process.bT;
            process.TT= process.CT - process.AT;
            process.wT = process.TT - process.bT;
            currentTime += process.bT;

        }

        System.out.println("Process\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time\tCompletion Time");
        double totalWaitingTime = 0, totalTurnaroundTime = 0;
        for(Process process : processes){
            System.out.printf("%s\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\n",
            process.name, process.AT, process.bT, process.wT, process.TT, process.CT);
            totalWaitingTime += process.wT;
            totalTurnaroundTime +=process.TT;
        }

        System.out.printf("\nAverage Waiting Time: %.2f\n", totalWaitingTime / processes.length);
        System.out.printf("Average Turnaround Time: %.2f\n", totalTurnaroundTime / processes.length);

      }
    
}
