import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

class Process {
    String name;
    int arrivalTime;
    int burstTime;
    int remainingTime;
    int waitingTime = 0;
    int turnaroundTime = 0;
    int completionTime = 0;

    public Process(String name, int arrivalTime, int burstTime) {
        this.name = name;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
        this.remainingTime = burstTime;
    }
}

public class SJFPre {
    public static void main(String[] args) {
        List<Process> processes = new ArrayList<>();
        processes.add(new Process("P1", 10, 2));
        processes.add(new Process("P2", 0, 10));
        processes.add(new Process("P3", 8, 4));
        processes.add(new Process("P4", 5, 5));

        // Sort processes by arrival time initially
        processes.sort(Comparator.comparingInt(p -> p.arrivalTime));

        int currentTime = 0;
        int completed = 0;
        int n = processes.size();
        Process currentProcess = null;

        while (completed != n) {
            // Select process with the shortest remaining time at current time
            currentProcess = null;
            for (Process process : processes) {
                if (process.arrivalTime <= currentTime && process.remainingTime > 0) {
                    if (currentProcess == null || process.remainingTime < currentProcess.remainingTime) {
                        currentProcess = process;
                    }
                }
            }

            if (currentProcess == null) {
                currentTime++;
            } else {
                // Process execution (1 unit of time)
                currentProcess.remainingTime--;
                currentTime++;

                // If process is completed
                if (currentProcess.remainingTime == 0) {
                    completed++;
                    currentProcess.completionTime = currentTime;
                    currentProcess.turnaroundTime = currentProcess.completionTime - currentProcess.arrivalTime;
                    currentProcess.waitingTime = currentProcess.turnaroundTime - currentProcess.burstTime;
                }
            }
        }

        // Display the results
        System.out.println("Process\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time\tCompletion Time");
        double totalWaitingTime = 0, totalTurnaroundTime = 0;
        for (Process process : processes) {
            System.out.printf("%s\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\n",
                    process.name, process.arrivalTime, process.burstTime, process.waitingTime, process.turnaroundTime, process.completionTime);
            totalWaitingTime += process.waitingTime;
            totalTurnaroundTime += process.turnaroundTime;
        }

        System.out.printf("\nAverage Waiting Time: %.2f\n", totalWaitingTime / n);
        System.out.printf("Average Turnaround Time: %.2f\n", totalTurnaroundTime / n);
    }
}
