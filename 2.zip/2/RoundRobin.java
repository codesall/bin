import java.util.LinkedList;
import java.util.Queue;

class Process {
    String name;
    int arrivalTime;
    int burstTime;
    int remainingTime;
    int waitingTime = 0;
    int turnaroundTime = 0;
    int completionTime = 0;

    public Process(String name, int arrivalTime, int burstTime) {
        this.name = name;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
        this.remainingTime = burstTime;
    }
}

public class RoundRobin {
    public static void main(String[] args) {
        // Initialize processes
        Process[] processes = {
                new Process("P1", 10, 2),
                new Process("P2", 0, 10),
                new Process("P3", 8, 4),
                new Process("P4", 5, 5)
        };
        int timeQuantum = 1;

        // Queue to hold processes in round-robin order
        Queue<Process> queue = new LinkedList<>();
        int currentTime = 0;
        int completed = 0;
        int n = processes.length;

        // Add processes to the queue as they arrive
        while (completed != n) {
            // Add processes that have arrived to the queue
            for (Process process : processes) {
                if (process.arrivalTime <= currentTime && process.remainingTime > 0 && !queue.contains(process)) {
                    queue.add(process);
                }
            }

            // If queue is empty, increment time to the next arrival time
            if (queue.isEmpty()) {
                currentTime++;
                continue;
            }

            // Fetch the next process in the queue
            Process currentProcess = queue.poll();

            // Execute the process for the time quantum (1 second)
            if (currentProcess.remainingTime > timeQuantum) {
                currentProcess.remainingTime -= timeQuantum;
                currentTime += timeQuantum;

                // Add processes that have arrived during this time quantum
                for (Process process : processes) {
                    if (process.arrivalTime <= currentTime && process.remainingTime > 0 && !queue.contains(process)) {
                        queue.add(process);
                    }
                }

                // Re-add the current process to the end of the queue if it still has remaining time
                queue.add(currentProcess);
            } else { // Process will complete within this time quantum
                currentTime += currentProcess.remainingTime;
                currentProcess.remainingTime = 0;
                currentProcess.completionTime = currentTime;
                currentProcess.turnaroundTime = currentProcess.completionTime - currentProcess.arrivalTime;
                currentProcess.waitingTime = currentProcess.turnaroundTime - currentProcess.burstTime;
                completed++;
            }
        }

        // Display the results
        System.out.println("Process\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time\tCompletion Time");
        double totalWaitingTime = 0, totalTurnaroundTime = 0;
        for (Process process : processes) {
            System.out.printf("%s\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\n",
                    process.name, process.arrivalTime, process.burstTime, process.waitingTime, process.turnaroundTime, process.completionTime);
            totalWaitingTime += process.waitingTime;
            totalTurnaroundTime += process.turnaroundTime;
        }

        System.out.printf("\nAverage Waiting Time: %.2f\n", totalWaitingTime / n);
        System.out.printf("Average Turnaround Time: %.2f\n", totalTurnaroundTime / n);
    }
}
