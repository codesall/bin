import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

class Process {
    String name;
    int arrivalTime;
    int burstTime;
    int waitingTime = 0;
    int turnaroundTime = 0;
    int completionTime = 0;
    boolean isCompleted = false;

    public Process(String name, int arrivalTime, int burstTime) {
        this.name = name;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
    }
}

public class SJFNonPreemptive {
    public static void main(String[] args) {
        List<Process> processes = new ArrayList<>();
        processes.add(new Process("P1", 10, 2));
        processes.add(new Process("P2", 0, 10));
        processes.add(new Process("P3", 8, 4));
        processes.add(new Process("P4", 5, 5));

        // Sort processes by arrival time initially
        processes.sort(Comparator.comparingInt(p -> p.arrivalTime));

        int currentTime = 0;
        int completed = 0;
        int n = processes.size();

        while (completed != n) {
            Process shortestJob = null;
            for (Process process : processes) {
                if (process.arrivalTime <= currentTime && !process.isCompleted) {
                    if (shortestJob == null || process.burstTime < shortestJob.burstTime) {
                        shortestJob = process;
                    }
                }
            }

            if (shortestJob == null) {
                currentTime++;
            } else {
                // Process the shortest job found
                currentTime += shortestJob.burstTime;
                shortestJob.completionTime = currentTime;
                shortestJob.turnaroundTime = shortestJob.completionTime - shortestJob.arrivalTime;
                shortestJob.waitingTime = shortestJob.turnaroundTime - shortestJob.burstTime;
                shortestJob.isCompleted = true;
                completed++;
            }
        }

        // Display the results
        System.out.println("Process\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time\tCompletion Time");
        double totalWaitingTime = 0, totalTurnaroundTime = 0;
        for (Process process : processes) {
            System.out.printf("%s\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\n",
                    process.name, process.arrivalTime, process.burstTime, process.waitingTime, process.turnaroundTime, process.completionTime);
            totalWaitingTime += process.waitingTime;
            totalTurnaroundTime += process.turnaroundTime;
        }

        System.out.printf("\nAverage Waiting Time: %.2f\n", totalWaitingTime / n);
        System.out.printf("Average Turnaround Time: %.2f\n", totalTurnaroundTime / n);
    }
}
